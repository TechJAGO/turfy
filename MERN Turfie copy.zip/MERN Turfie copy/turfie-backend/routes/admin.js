const express = require('express')
const { loginAdmin, signAdmin } = require('../controllers/userController')


const router = express.Router()

// login 

router.post('/login' , loginAdmin)

// signup 

router.post('/signup' , signAdmin)

module.exports = router