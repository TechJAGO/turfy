import React from 'react'
import { useBookingContext } from '../hooks/useBookingContext'
import formatDistanceToNow from 'date-fns/formatDistanceToNow'
import { useAuthContext } from '../hooks/useAuthContext'

const BookingDetails = ({ booking }) => {

  const { dispatch } = useBookingContext()
  const { admin } = useAuthContext()

  const handleDeleteClick = async ()=>{

    if (!admin){
      return
    }
    const response = await fetch('http://localhost:4000/mybookings/' + booking._id, {
      method:'DELETE',
      headers:{
        'Authorization' : `Bearer ${ admin.authtoken }`
    }
    })
    const json = await response.json()
    // console.log(booking._id)

    if(response.ok){
      dispatch({type: 'DELETE_BOOKING', payload: json})
    }
  }

  // const handleEditClick = async ()=>{
  //   const response = await fetch('http://localhost:4000/mybookings/' + booking._id, {
  //     method:'PATCH'
  //   })
  //   const json = await response.json()
  //   console.log(booking._id)
  
  //   if(response.ok){
  //     dispatch({type: 'UPDATE_BOOKING', payload: json})
  //   }
  // }

  return (
    <div className='booking-details'>
      <h4><strong>Booker Name: </strong>{booking.bookerName}</h4>
      <p><strong>Booking Amount: </strong> {booking.bookerAmount}</p>
      <p><strong>Booking Time: </strong> {booking.bookerDnT}</p>
      <p><strong>Booker Number: </strong> {booking.bookerPhoneno}</p>
      <p>Updated: {formatDistanceToNow(new Date(booking.updatedAt), { addSuffix: true })}</p>
      <p>Booked: {formatDistanceToNow(new Date(booking.createdAt), { addSuffix: true })}</p>
      <span className='material-symbols-outlined casual' onClick={handleDeleteClick}>Delete</span>
      {/* <span className='material-symbols-outlined casual1' onClick={handleEditClick}>Edit</span> */}

    </div>
  )
}

export default BookingDetails
