import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuthContext } from '../hooks/useAuthContext'
import { useLogout } from '../hooks/useLogout'

const Navbar = () => {

  let navigate = useNavigate()

  const { logout } = useLogout()

  const { admin } = useAuthContext()

  const handleClick = () =>{
    logout()
    navigate('/')
  }

  return (
    <header>
        <div className='container'>
            <Link to="/"> <h1>Turfie</h1></Link>
        
        <nav>
            <Link to="/aboutus"> <h3>About Us</h3></Link>
        
            <Link to="/contactus"> <h3>Contact Us</h3></Link>


            {admin && (<>
            <Link to="/myturf"> <h3>My Turfs</h3></Link>
            <button onClick={handleClick}>Logout</button></>)}

            {!admin && ( <>
            
            <Link to="/turflist"> <h3>Available Turfs</h3></Link>
            <Link to="/login"> <h3>Login</h3></Link>
            <Link to="/signup"> <h3>Sign-Up</h3></Link></>)}
        </nav>
        </div>
    </header>
  )
}

export default Navbar
