import React, { useState } from "react";
import { useBookingContext } from "../hooks/useBookingContext";
import { useAuthContext } from "../hooks/useAuthContext";


const BookingForm = () => {
  const [bookerName, setBookername] = useState("");
  const [bookerAmount, setBookeramount] = useState("");
  const [bookerDnT, setBookerDnT] = useState("");
  const [bookerPhoneno, setBookerphoneno] = useState("");
  const [error, setError] = useState(null);
  const { dispatch }= useBookingContext();
  const [emptyFields, setEmptyFields] = useState([])
  const { admin } = useAuthContext()

    const handleSubmit = async (e)=>{
        e.preventDefault()

        if (!admin){
          setError('You must be logged in')
          return
        }

        const booking = { bookerName, bookerAmount, bookerDnT, bookerPhoneno }

        const response = await fetch('http://localhost:4000/mybookings',{
            method:'POST',
            body: JSON.stringify(booking),
            headers:{
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${ admin.authtoken }`
            }
        })
        const json = await response.json()

        // console.log(admin.authtoken)

        if(!response.ok){
            setError(json.error)
            setEmptyFields(json.emptyFields)
        }

        if(response.ok){
            setBookername('')
            setBookeramount('')
            setBookerDnT('')
            setBookerphoneno('')
            setError(null)
            setEmptyFields([])
            console.log('New booking added', json)
            dispatch({type: 'CREATE_BOOKINGS', payload: json})
        }
    }

  return (

    <div>
      <form action="" className="create" onSubmit={handleSubmit}>
        <h2> New Booking Form </h2>
        <label>Booker Name: </label>
        <input
          type="text"
          onChange={(e) => setBookername(e.target.value)}
          value={bookerName}
          className={emptyFields.includes('bookerName')? 'error':''}
        />

        <label>Booker Amount: </label>
        <input
          type="text"
          onChange={(e) => setBookeramount(e.target.value)}
          value={bookerAmount}
          className={emptyFields.includes('bookerAmount')? 'error':''}
        />

        <label>Booking Time: </label>
        <input
          type="text"
          onChange={(e) => setBookerDnT(e.target.value)}
          value={bookerDnT}
          className={emptyFields.includes('bookerDnT')? 'error':''}
        />

        <label>Booker Contact Info: </label>
        <input
          type="text"
          onChange={(e) => setBookerphoneno(e.target.value)}
          value={bookerPhoneno}
          className={emptyFields.includes('bookerPhoneno')? 'error':''}
        />

        <button>Add Booking</button>
        {error && <div className="error">{error}</div>}
      </form>
    </div>
  );
};

export default BookingForm;
