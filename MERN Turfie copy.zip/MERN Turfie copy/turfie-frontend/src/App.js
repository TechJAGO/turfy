import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './index.css';

// pages and components 
import Layout from './pages/Layout';
import Navbar from './components/Navbar';
import SignupAdmin from './pages/SignupAdmin';
import LoginAdmin from './pages/LoginAdmin';
import Homepage from './pages/Homepage';
import Footertag from './pages/Footertag';
import Mybookings from './pages/Mybookings';



function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar/>
        <div className="pages">
          <Routes>
          <Route path='/' element={ <Homepage/> }/>
            <Route path='/myturf' element={ <Layout/> }/>
            <Route path='/signup' element={ <SignupAdmin/> }/>
            <Route path='/login' element={ <LoginAdmin/> }/>
            <Route path='/myturfdetails' element={ <Mybookings/> }/>

          </Routes>
        </div>
        <Footertag/>
      </BrowserRouter>
    </div>
  );
}

export default App;
