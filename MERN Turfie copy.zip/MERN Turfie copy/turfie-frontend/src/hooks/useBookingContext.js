import { BookingContext } from "../context/BookingContext";
import { useContext } from "react";

export const useBookingContext = () =>{
    const context = useContext (BookingContext)

    if(!context){
        throw Error ('useBookingContext must be used inside an BookingContextProvider')
    }

    return context
}