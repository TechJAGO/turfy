import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useSignup } from "../hooks/useSignup"

const Signup = () => {

  let navigate = useNavigate()
  const [aname, setaName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('')
  const [turfname, setTurfname] = useState('')
  const [turfAd, setTurfad] = useState('')
  const {signup, error, isLoading} = useSignup()

  const handleSubmit = async (e) => {
    e.preventDefault()
    await signup( aname, email, password, phone, turfname, turfAd)
    navigate('/')
  }

  return (
    <form className="signup" onSubmit={handleSubmit}>
      <h3>ADMIN REGISTRATION</h3>
      
      <label>Name:</label>
      <input 
        type="name" 
        onChange={(e) => setaName(e.target.value)} 
        value={aname} 
      />
      <label>Email address:</label>
      <input 
        type="email" 
        onChange={(e) => setEmail(e.target.value)} 
        value={email} 
      />
      <label>Password:</label>
      <input 
        type="password" 
        onChange={(e) => setPassword(e.target.value)} 
        value={password} 
      />
      <label>Contact Information:</label>
      <input 
        type="phone" 
        onChange={(e) => setPhone(e.target.value)} 
        value={phone} 
      />
      <label>Turf Name:</label>
      <input 
        type="turfname" 
        onChange={(e) => setTurfname(e.target.value)} 
        value={turfname} 
      />
      <label>Turf Address:</label>
      <input 
        type="turfad" 
        onChange={(e) => setTurfad(e.target.value)} 
        value={turfAd} 
      />

      <button disabled={isLoading}>Sign up</button>
      {error && <div className="error">{error}</div>}
    </form>
  )
}

export default Signup