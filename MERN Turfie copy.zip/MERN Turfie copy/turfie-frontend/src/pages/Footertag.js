import React from "react";

const Footertag = () => {
  return (
    <div className="main">
      <div class="footertag">
        <div className="mainfootersec">
          <div class="sec1">
            <strong>
              <h3>About Us</h3>
              <p>
                We are a start-up that aims to easy the hassle between the
                Turf-Owner and Customer.
              </p>
            </strong>
          </div>
          <div class="sec2">
            <strong>
              <h3>Contact Us</h3>
              <p>Number: 8369220232 / 8356905704</p>
              <p>Email us: jating@softcell.com</p>
              <p>Whatsapp us @8369220232 / 8356905704</p>
            </strong>
          </div>
          <div class="sec3">
            <strong>Social media handles</strong>
          </div>
        </div>
        <h3 style={{ color: "white" }}>All rights reserved by Turfy@2023</h3>
      </div>
    </div>
  );
};

export default Footertag;
